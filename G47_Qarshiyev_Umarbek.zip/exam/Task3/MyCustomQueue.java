package Task3;

import org.w3c.dom.Node;

import java.util.Arrays;
import java.util.StringJoiner;

/**
 * Created by: Umar
 * DateTime: 8/28/2024 8:30 PM
 */
public class MyCustomQueue<E> {
    private int elementCount = 0;
    private Object[] elementData;
    private static final int DEFAULT_CAPACITY = 10;



    public MyCustomQueue(int size) {
        this.elementData = new Object[size];
    }

    public MyCustomQueue() {
        this(DEFAULT_CAPACITY);
    }

    private boolean isEmpty() {
        return elementCount == 0;
    }

    private boolean isFull(){
        return elementCount == elementData.length;
    }

    public boolean enqueue(E element) {
        if (isFull()) {
            throw new RuntimeException("Queue is full");
        }
        elementData[elementCount++] = element;
        return true;
    }

    @SuppressWarnings("unchecked")
    public E dequeue() {
        if (isEmpty()) {
            throw new RuntimeException("Queue is empty");
        }
        E element = (E) elementData[0];
        for (int i = 0; i < elementCount; i++) {
            elementData[i] = elementData[i + 1];
        }
        elementCount--;
        return element;
    }

    @SuppressWarnings("unchecked")
    public E peek(){
        if (isEmpty()) {
            throw new RuntimeException("Queue is empty");
        }
        E elementOne = (E) elementData[0];
        return elementOne;
    }


    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(", ","[","]");
        for (int i = 0; i < elementCount; i++) {
            if (elementData[i] != null) {
                sj.add(elementData[i].toString());
            }
        }
        return sj.toString();
    }

    public static void main(String[] args) {
        MyCustomQueue<Integer> customQueue = new MyCustomQueue<>();
        customQueue.enqueue(2);
        customQueue.enqueue(1);
        customQueue.enqueue(3);
        customQueue.enqueue(5);
        customQueue.enqueue(4);

        System.out.println("customQueue = " + customQueue);

        System.out.println("customQueue.dequeue() = " + customQueue.dequeue());
        System.out.println("customQueue = " + customQueue);
        System.out.println("customQueue.peek() = " + customQueue.peek());
    }

}
